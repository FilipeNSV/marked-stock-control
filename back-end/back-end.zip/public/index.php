<?php

require __DIR__ . '/../routes/router.php';
